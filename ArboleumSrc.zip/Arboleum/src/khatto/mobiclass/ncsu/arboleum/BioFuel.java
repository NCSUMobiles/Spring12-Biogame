package khatto.mobiclass.ncsu.arboleum;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Parcel;
import android.os.Parcelable;

public class BioFuel implements Parcelable{
	
	private enum form{
		SwitchGrass,
		Tree,
		Algae 
	}
	
	private String type = "";
	//Can be SwitchGrass, Trees, Algae.
	private int yield = 0;
	private int currentTurn = 0;
	private int turnsToMaturity = 0;
	private int purchaseCost = 0;
	

	
	public BioFuel(){
		type = "Grass";
		setInfo();
	}
	
	public BioFuel(String s){
		type = s;
		setInfo();
	}
	
	public void setInfo(){
		if (type.equals("Grass")){
			yield = 350;
			turnsToMaturity = 3;
			setPurchaseCost(200);
		}
		if (type.equals("Algae")){
			yield = 550;
			turnsToMaturity = 4;
			setPurchaseCost(300);
		}
		if (type.equals("Trees")){
			yield = 855;
			turnsToMaturity = 5;
			setPurchaseCost(450);
		}
		
	}
	
	public String getType(){
		return type;
	}
	
	
	public int getYield(){
		return yield;
	}
	
	@Override
	public int describeContents() {
		// TODO Auto-generated method stub
		return 0;
	}

	public void nextTurn(){
		currentTurn++;
	}
	
	public boolean readyToHarvest(){
		return (currentTurn >= turnsToMaturity);
	}
	
	public int getTurnsToMaturity(){
		return turnsToMaturity;
	}
	
	public int getCurrentTurn(){
		return currentTurn;
	}
	
	public double maturityRatio(){
		return currentTurn/turnsToMaturity;
	}
	
	public Bitmap getTurnImage(Resources r){
		
		if (currentTurn == 1 && type.equals("Grass")) return BitmapFactory.decodeResource(r, R.drawable.plotswitchgrass1);
		if (currentTurn == 2 && type.equals("Grass")) return BitmapFactory.decodeResource(r, R.drawable.plotswitchgrass2);
		if (currentTurn >= 3 && type.equals("Grass")) return BitmapFactory.decodeResource(r, R.drawable.plotswitchgrass3);
		if (currentTurn == 1 && type.equals("Algae")) return BitmapFactory.decodeResource(r, R.drawable.plotalgae1);
		if (currentTurn == 2 && type.equals("Algae")) return BitmapFactory.decodeResource(r, R.drawable.plotalgae2);
		if (currentTurn == 3 && type.equals("Algae")) return BitmapFactory.decodeResource(r, R.drawable.plotalgae3);
		if (currentTurn >= 4 && type.equals("Algae")) return BitmapFactory.decodeResource(r, R.drawable.plotalgae4);
		if (currentTurn == 1 && type.equals("Trees")) return BitmapFactory.decodeResource(r, R.drawable.plottree1);
		if (currentTurn == 2 && type.equals("Trees")) return BitmapFactory.decodeResource(r, R.drawable.plottree2);
		if (currentTurn == 3 && type.equals("Trees")) return BitmapFactory.decodeResource(r, R.drawable.plottree3);
		if (currentTurn == 4 && type.equals("Trees")) return BitmapFactory.decodeResource(r, R.drawable.plottree4);
		if (currentTurn >= 5 && type.equals("Trees")) return BitmapFactory.decodeResource(r, R.drawable.plottree5);
		else return BitmapFactory.decodeResource(r, R.drawable.plotempty);
	}
	
	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeString(type);
		dest.writeInt(yield);
		dest.writeInt(currentTurn);
		dest.writeInt(turnsToMaturity);
		
	}
	
	public BioFuel(Parcel par){
		this.type = par.readString();
		this.yield = par.readInt();
		this.currentTurn = par.readInt();
		this.turnsToMaturity = par.readInt();
	}
	
	public void setPurchaseCost(int purchaseCost) {
		this.purchaseCost = purchaseCost;
	}

	public int getPurchaseCost() {
		return purchaseCost;
	}

	public static final Parcelable.Creator<BioFuel> CREATOR = new Parcelable.Creator<BioFuel>() {
        public BioFuel createFromParcel(Parcel in) {
            return new BioFuel(in);
        }

        public BioFuel[] newArray(int size) {
            return new BioFuel[size];
        }
    };
}
