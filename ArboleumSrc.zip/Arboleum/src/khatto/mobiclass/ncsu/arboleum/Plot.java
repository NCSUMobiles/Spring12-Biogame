package khatto.mobiclass.ncsu.arboleum;


import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Parcel;
import android.os.Parcelable;
import android.widget.Toast;


public class Plot implements Parcelable{
	
	/**
	 * Nutrients - Represents the current nutritional health of a plot
	 * Maturity - Represents the overall age of the plot
	 * Toxicity - Represents the current level toxicity within a plot
	 * Yield - Represents the total Biomass yield a plot will produce
	 * pest - Represents a pest that a Plot has
	 */
	private String name;
	private double Nutrients;
	private double Maturity = 0;
	private double Toxicity;
	private double Yield;
	private Pest pest;
	private BioFuel bioFuel;	
		
	private int x;
	private int y;
	private int imagewidth;
	private int imageheight;
	
	private Bitmap image;
	
	private Resources resources;
	
	
	public Plot(Resources r){
		resources = r;
	}
	
	public void nextTurn(){
		
		if (bioFuel != null){
			bioFuel.nextTurn();
			setImage(bioFuel.getTurnImage(resources));
		}
		Maturity++;
		if (Nutrients >= 5) Nutrients -= 5;
		if (Toxicity >= 15) Toxicity -= 15;
		
	}
	
	public void piedmontSetup(){
		Nutrients = 90;
		Maturity = 0;
		Toxicity = 0;
		Yield = 15;		
		image = BitmapFactory.decodeResource(resources, R.drawable.plotempty);
		imagewidth = image.getWidth();
		imageheight = image.getHeight();
	}
	
	public void Harvest(){
		
	}
	
	//GETTERS AND SETTERS AND PARCELABLE
	
	public double getNutrients(){
		return Nutrients;
	}
	
	public int getImageWidth(){
		return imagewidth;
	}
	
	public int getImageHeight(){
		return imageheight;
	}
	
	public double getToxicity(){
		return Toxicity;
	}
	
	public double getYield(){		
		return Yield;
	}
	
	public void setYield(){
		/*
		if (!bioFuel.equals(null)) Yield = bioFuel.getYield();
		if (!pest.equals(null)) Yield -= pest.getHarmValue();
		*/
	};
	
	public void setName(String s){
		name = s;
	}
	
	public double getMaturity(){
		return Maturity;
	}
	
	public BioFuel getBioFuel(){
		return bioFuel;
	}
	
	public void setBioFuel(BioFuel b){
		this.bioFuel = b;
		setYield();
	}
	
	public void clearBioFuel(){
		this.bioFuel = null;
		setYield();
	}
	
	public void setPest(Pest p){
		pest = p;
		setYield();
	}
	
	public boolean hasPest(){
		if (pest != null) return true;
		else return false;
	}
	
	public Pest getPest(){
		return pest;
	}

	@Override
	public int describeContents() {
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		//Writing the Plot's Values
		dest.writeString(name);
		dest.writeDouble(Nutrients);
		dest.writeDouble(Maturity);
		dest.writeDouble(Toxicity);
		dest.writeDouble(Yield);
		
	}
	
	public String getName(){
		return name;
	}
	
	public Plot(Parcel par){
		this.name = par.readString();
		this.Nutrients = par.readDouble();
		this.Maturity = par.readDouble();
		this.Toxicity = par.readDouble();
		this.Yield = par.readDouble();
	}
	
	public void setX(int x) {
		this.x = x;
	}

	public int getX() {
		return x;
	}

	public void setY(int y) {
		this.y = y;
	}

	public int getY() {
		return y;
	}

	public void setImage(Bitmap image) {
		this.image = image;
	}

	public Bitmap getImage() {
		return image;
	}

	public static final Parcelable.Creator<Plot> CREATOR = new Parcelable.Creator<Plot>() {
        public Plot createFromParcel(Parcel in) {
            return new Plot(in);
        }

        public Plot[] newArray(int size) {
            return new Plot[size];
        }
    };
    
    public void changeNutrients(int i){
    	Nutrients += i;
    }
    
    public void setNutrients(double moisture){
    	Nutrients = moisture;
    }
    
    public void changeToxicity(int i){
    	Toxicity += i;
    }
    
    public boolean isTouched(int eventx, int eventy){
    	boolean touched = false;
    	int[] plot1xrange = new int[]{x,x+imagewidth};	   	
    	int[] plot1yrange = new int[]{y, y+imageheight};   
    	if ((eventx >= plot1xrange[0] && eventx <= plot1xrange[1] ) && (eventy >= plot1yrange[0] && eventy <= plot1yrange[1] ) ) {
  			return true;
  			
   	   }
    	return touched;
    }


	public boolean hasBioFuel() {
		if (bioFuel != null) return true;
		else return false;
	};
	

}
