package khatto.mobiclass.ncsu.arboleum;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;

public class Icon {
	
	private Bitmap image;
	private String name;
	private Resources resources;
	private int x;
	private int y;
	private int sidebarX;
	private int windowY;
	
	public Icon(String s, Resources r, int x, int y){
		name = s;
		resources = r;
		sidebarX = x;
		windowY = y;
		setup();		
	}
	
	public void setup(){
		if (name.equals("Silo")){
			image = BitmapFactory.decodeResource(resources, R.drawable.siloicon);
			setX(sidebarX+10);
			setY(windowY-200);			
		}
		if (name.equals("House")){
			image = BitmapFactory.decodeResource(resources, R.drawable.houseicon);
			setX(sidebarX+10);
			setY(175);			
		}
		if (name.equals("NextTurn")){
			image = BitmapFactory.decodeResource(resources, R.drawable.newturnicon);
			setX(sidebarX+10);
			setY(windowY-image.getHeight()-10);			
		}
		if (name.equals("SeasonIcon")){
			image = BitmapFactory.decodeResource(resources, R.drawable.seasoniconspring); 
			setX(sidebarX+10);
			setY(150);
			
		}
		
	}
	
	public void setSeason(String s){
		if (s == "Sprint"){
			image = BitmapFactory.decodeResource(resources, R.drawable.seasoniconspring); 
		}
		if (s == "Summer"){
			image = BitmapFactory.decodeResource(resources, R.drawable.seasoniconsummer); 
		}
		if (s == "Autumn"){
			image = BitmapFactory.decodeResource(resources, R.drawable.seasoniconautumn); 
		}
		if (s == "Winter"){
			image = BitmapFactory.decodeResource(resources, R.drawable.seasoniconwinter); 
		}
		
	}
	
	public void Draw(Canvas canvas){
		canvas.drawBitmap(image,x, y, null);
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getX() {
		return x;
	}

	public void setY(int y) {
		this.y = y;
	}

	public int getY() {
		return y;
	}
	
	public boolean isTouched(int eventx, int eventy){
    	boolean touched = false;
    	int[] plot1xrange = new int[]{x,x+image.getWidth()};	   	
    	int[] plot1yrange = new int[]{y, y+image.getHeight()};   
    	if ((eventx >= plot1xrange[0] && eventx <= plot1xrange[1] ) && (eventy >= plot1yrange[0] && eventy <= plot1yrange[1] ) ) {
  			return true;
  			
   	   }
    	return touched;
    };
	

}
