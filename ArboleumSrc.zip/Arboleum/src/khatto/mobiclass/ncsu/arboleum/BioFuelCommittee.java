package khatto.mobiclass.ncsu.arboleum;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;

public class BioFuelCommittee extends Activity{
	
	TextView HighestMoney;
	TextView Happiness;
	TextView NumberOfCrops;
	TextView Results;
	int highestMoney = 0;
	int happiness = 0;
	int numOfCrops = 0;
	Context con;
	
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.bfclayout);
		Intent i = getIntent();
		
		HighestMoney = (TextView) findViewById(R.id.highestamountofmoneyforid);
		highestMoney = i.getIntExtra("highest", 0);
		HighestMoney.setText(""+highestMoney);
		
		Happiness = (TextView) findViewById(R.id.farmhappinessforid);
		happiness = i.getIntExtra("health", 0);
		Happiness.setText(""+happiness);
		
		NumberOfCrops = (TextView) findViewById(R.id.totalcropsharvestedforid);
		numOfCrops = i.getIntExtra("harvest", 0);
		NumberOfCrops.setText(""+numOfCrops);
		
		con = this;
		Results = (TextView) findViewById(R.id.resultsforid);	
		Results.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				if (numOfCrops >= 8 && happiness > 70){
					showDialog(1);
				} else{
					showDialog(2);
				}				
			}			
		});
		
		
	}
	
	@Override
	protected Dialog onCreateDialog( int id ){
		
		if (id == 1){
			new PlaySound(con, "Correct");
			final AlertDialog.Builder alert = new AlertDialog.Builder(this);
			alert.setMessage("The BioFuels Commitee say you've done an excellent job maintaining this BioFuels farm!  Way to go!")
	 	       .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int button) {
						finish();

					}
				});
	 	       return alert.create();
	 	      
		}
		
		if (id == 2){
			new PlaySound(con, "Wrong");
			final AlertDialog.Builder alert = new AlertDialog.Builder(this);
			alert.setMessage("The BioFuels Commitee regret to inform you that you did not do a good job this time around.  Try harder next time!")
	 	       .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int button) {
						finish();

					}
				});
	 	       return alert.create();
	 	      
		}
		
		return null;
	}

}
