package khatto.mobiclass.ncsu.arboleum;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class TitleScreen extends Activity{
	
	public Context con;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.titlescreenlayout);
		
		con = this;
		
		
		Button StartButton = (Button) findViewById(R.id.startbutton);
		Button GameButton = (Button) findViewById(R.id.startgamebutton);
		Button InfoButton = (Button) findViewById(R.id.infobutton);
		
		/*
		StartButton.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				Intent j = new Intent(TitleScreen.this, FarmLandActivity.class);
				startActivity(j);
				overridePendingTransition(R.anim.fadein, R.anim.fadeout);
				finish();				
			}			
		});
		*/
		GameButton.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				new PlaySound(con, "Correct");
				CountDownTimer cd = new CountDownTimer(1800, 100){

					@Override
					public void onFinish() {
						//Intent j = new Intent(TitleScreen.this, FarmLandActivity.class);
						Intent j = new Intent(TitleScreen.this, Tutorial.class);
						startActivity(j);
						overridePendingTransition(R.anim.fadein, R.anim.fadeout);
						finish();
						
					}

					@Override
					public void onTick(long millisUntilFinished) {
						// TODO Auto-generated method stub
						
					}
					
				};
				cd.start();
								
			}			
		});
		
		InfoButton.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {				
				makeToast("About:\n\n"+"About Arboleum (version 5.7.0)\n\n"+"Version 5.7.0 has most of our implementation for our biofuels game. The only implementations missing are the following:\n\n"+"\n1. Silo integration"+"\n2. Music integration"+"\n\nThese implementations are missing due to time constraints."+"\n\nArboleum is an educational biofuels game designed specifically for the android platform. Arboleum is a grid-style farming game where the player plants biofuel crops to try and achieve the most amount of money to keep playing. The game simulates through multiple years going through each of the four seasons giving the player the feel of maintaining their own biofuel crops. Throughout the game the soils toxicity and moisture are constantly changing based on how you maintain your crops and the player must make sure the crops don't die. During transitions between seasons, the user is shown random facts and quotes about biofuels to help them understand more about biofuels."+"\n\nArboleum was developed by Khiry Arnold with help from Matthew Gray, Daniel Morgan, and Chris Kampe in North Carolina State University's special topics Mobile class Spring 2012."
);			
			}
		});
		
	}
		
	public void makeToast(String s){
		String tempstr = s;
    	int duration = Toast.LENGTH_SHORT;
    	Toast toast = Toast.makeText(getApplicationContext(), tempstr, duration);
    	toast.show();
	}

}
