package khatto.mobiclass.ncsu.arboleum;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class PlotActivity extends Activity{
	
	private Plot thePlot;
	ImageView bioFuelButton;
	ImageView whichPlot;
	TextView FarmMoney;
	
	ImageView waterButton;
	ImageView harvestButton;
	
	Context con;
	
	private BioFuel theBioFuel;
	private boolean hasBioFuel;
	private Pest thePest;
	private boolean hasPest;
	
	private int tempCost = 0;
	
	public boolean hasHarvested = false;
	
	public int farmMoney = 0;
	
	public int harvestValue = 0;
	
	public int bioFuelChoice = 0;
	public String[] bioFuelChoices  = {"None", "Switch Grass", "Algae", "Tree"};
			
	@Override
	public void onCreate(Bundle savedInstanceState) {

		requestWindowFeature(Window.FEATURE_NO_TITLE);
		this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON, WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
		
		super.onCreate(savedInstanceState);
		
		con = this;
		Intent i = getIntent();
		thePlot = (Plot) i.getParcelableExtra("plot");
		setContentView(R.layout.plotactivitylayout);	
		
		farmMoney = i.getIntExtra("money", 0);
		FarmMoney = (TextView) findViewById(R.id.farmmoney);
		FarmMoney.setText("$"+farmMoney);
		
		waterButton = (ImageView) findViewById(R.id.waterbutton);
		waterButton.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				if (thePlot.getNutrients() == 100 && farmMoney >= 20){
					showDialog(5);
				}else {
					if (farmMoney >= 20){
						farmMoney -= 20;
						new PlaySound(con, "Water");
						if (thePlot.getNutrients() < 90) thePlot.changeNutrients(10);
						else thePlot.setNutrients(100);
						updateTexts();
					} else{
						showDialog(3);
					}
				}				
			}			
		});
		harvestButton = (ImageView) findViewById(R.id.harvestbutton);
		harvestButton.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				if (theBioFuel != null){
					if (theBioFuel.readyToHarvest()){
						showDialog(10);
					}
					else {
						showDialog(11);
					}
				} else {
					
				};
				
			}
			
		});
		//Intent j = getIntent();		
		
		
		bioFuelButton = (ImageView) findViewById(R.id.plotbiofuel);
		
		if (i.hasExtra("biofuel")){
			theBioFuel = (BioFuel) i.getParcelableExtra("biofuel");
			setPestAndBioFuel();
		}
		
		try{
			
			if (i.hasExtra("pest")) thePest = (Pest) i.getParcelableExtra("pest");
			
			hasPest = true;
			
		} catch(Exception e){
			
		}
		
		TextView Name = (TextView) findViewById(R.id.plotname);
		TextView Nutrients = (TextView) findViewById(R.id.plotnutrients);
		TextView Maturity = (TextView) findViewById(R.id.plotmaturity);
		TextView Toxicity = (TextView) findViewById(R.id.plottoxicity);		
		TextView Yield = (TextView) findViewById(R.id.plotyield);
		whichPlot = (ImageView) findViewById(R.id.whichplotpic);
		
		Name.setText(thePlot.getName());
		Nutrients.setText(""+((int)thePlot.getNutrients())+"%");
		if (theBioFuel == null) Maturity.setText("No BioFuel");
		else Maturity.setText(""+((int)theBioFuel.getCurrentTurn())+" Seasons");
		Toxicity.setText(""+((int)thePlot.getToxicity())+"%");
		Yield.setText("Yield: "+thePlot.getYield());
		if (thePlot.getName().contains("One")) {
			whichPlot.setImageDrawable(getResources().getDrawable(R.drawable.which1));
		}
		if (thePlot.getName().contains("Two")) {
			whichPlot.setImageDrawable(getResources().getDrawable(R.drawable.which2));
		}
		if (thePlot.getName().contains("Three")) {
			whichPlot.setImageDrawable(getResources().getDrawable(R.drawable.which3));
		}
		if (thePlot.getName().contains("Four")) {
			whichPlot.setImageDrawable(getResources().getDrawable(R.drawable.which4));
		}
		if (thePlot.getName().contains("Five")) {
			whichPlot.setImageDrawable(getResources().getDrawable(R.drawable.which5));
		}
		if (thePlot.getName().contains("Six")) {
			whichPlot.setImageDrawable(getResources().getDrawable(R.drawable.which6));
		}
		if (thePlot.getName().contains("Seven")) {
			whichPlot.setImageDrawable(getResources().getDrawable(R.drawable.which7));
		}
		if (thePlot.getName().contains("Eight")) {
			whichPlot.setImageDrawable(getResources().getDrawable(R.drawable.which8));
		}
		if (thePlot.getName().contains("Nine")) {
			whichPlot.setImageDrawable(getResources().getDrawable(R.drawable.which9));
		}
		
		bioFuelButton.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				if (theBioFuel == null) showDialog(1);	
				else {
					showDialog(2);
				}
			}			
		});
	}
	
	public void waterOperations(){
		new PlaySound(this, "Water");
		farmMoney -= 20;
		updateTexts();
	}
	
	public void updateTexts(){
		TextView Nutrients = (TextView) findViewById(R.id.plotnutrients);
		TextView Maturity = (TextView) findViewById(R.id.plotmaturity);
		TextView Toxicity = (TextView) findViewById(R.id.plottoxicity);		
		TextView Yield = (TextView) findViewById(R.id.plotyield);
		
		
		Nutrients.setText(""+((int)thePlot.getNutrients())+"%");
		if (theBioFuel == null) Maturity.setText("No BioFuel");
		else Maturity.setText(""+((int)theBioFuel.getCurrentTurn())+" Seasons");
		Toxicity.setText(""+((int)thePlot.getToxicity())+"%");
		FarmMoney.setText("$"+farmMoney);
	}
	
	public void canPlantCheck(){
		if (bioFuelChoice == 1) {					
			if (canAffordMoney(1)) showDialog(20);
		}
		if (bioFuelChoice == 2) {					
			if (canAffordMoney(2)) showDialog(20);
		}
		if (bioFuelChoice == 3) {					
			if (canAffordMoney(3)) showDialog(20);
		}	
	}
	
	public void plantingOperations(){
		if (bioFuelChoice == 0) {
			bioFuelButton.setImageDrawable(getResources().getDrawable(R.drawable.biofuelbuttonplant));
			theBioFuel = null;
		}
		if (bioFuelChoice == 1) {					
			if (canAfford(1)){
				bioFuelButton.setImageDrawable(getResources().getDrawable(R.drawable.biofuelbuttonswitchgrass));
				theBioFuel = new BioFuel("Grass");		
				new PlaySound(con, "Harvest");
			}										
		}
		if (bioFuelChoice == 2) {					
			if (canAfford(2)){
				bioFuelButton.setImageDrawable(getResources().getDrawable(R.drawable.biofuelbuttonalgae));
				theBioFuel = new BioFuel("Algae");
				new PlaySound(con, "Harvest");
			}
		}
		if (bioFuelChoice == 3) {					
			if (canAfford(3)){
				bioFuelButton.setImageDrawable(getResources().getDrawable(R.drawable.biofuelbuttontrees));
				theBioFuel = new BioFuel("Trees");
				new PlaySound(con, "Harvest");
			}
		}	
		updateTexts();
	}
	
	@Override
	protected Dialog onCreateDialog( int id )
	{
		if (id == 1){		
	    	
			return new AlertDialog.Builder( this )
 	       .setTitle( "Select BioFuel" )
 	       .setSingleChoiceItems(bioFuelChoices, bioFuelChoice,  new DialogInterface.OnClickListener(){			

			@Override
			public void onClick(DialogInterface dialog, int select) {
				bioFuelChoice = select;				
			}
 	    	   
 	       })
 	       .setPositiveButton( "OK", new DialogInterface.OnClickListener(){
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				canPlantCheck();
							
			}
		})
 	       .create();
		}
		
		//CONFIRM CROP SELECTION
		if (id == 20){
			final AlertDialog.Builder alert = new AlertDialog.Builder(this);
	 	       alert.setTitle( "Confirm BioFuel" )
	 	       .setMessage("Would you like to Plant this BioFuel?")
	 	       .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int button) {
						plantingOperations();

					}
				})
	 	      .setNegativeButton("No", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int button) {
						

					}
				});
	 	       return alert.create();
		}
		
		
		if (id == 2){
			final AlertDialog.Builder alert = new AlertDialog.Builder(this);
	 	       alert.setTitle( "Destroy Crop?" )
	 	       .setMessage("Would you like to clear the plot by plowing it?")
	 	       .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int button) {
						bioFuelChoice = 0;
						bioFuelButton.setImageDrawable(getResources().getDrawable(R.drawable.biofuelbuttonplant));
						theBioFuel = null;
						new PlaySound(con, "Harvest");

					}
				})
	 	      .setNegativeButton("No", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int button) {
						

					}
				});
	 	       return alert.create();
		}
		
		if (id == 3){
			final AlertDialog.Builder alert = new AlertDialog.Builder(this);
	 	       
	 	       alert.setMessage("You don't have the $20 necessary to water this plot.")
	 	       .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int button) {
						

					}
				});
	 	       return alert.create();
		}
		
		if (id == 6){
			final AlertDialog.Builder alert = new AlertDialog.Builder(this);
	 	       
	 	       alert.setMessage("The plot is already at maximum moisture.")
	 	       .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int button) {
						

					}
				});
	 	       return alert.create();
		}
		
		//TOO BROKE TO BUY
		if (id == 4){
			final AlertDialog.Builder alert = new AlertDialog.Builder(this);
			alert.setMessage("You don't have enough money to purchase this BioFuel.")
	 	       .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int button) {
						

					}
				});
	 	       return alert.create();
	 	      
		}
		
		if (id == 5){
			final AlertDialog.Builder alert = new AlertDialog.Builder(this);
	 	       
	 	       alert.setMessage("This plot is already at 100% moisture.  Water anyway?  (Costs $20)")
	 	       .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int button) {
						waterOperations();
					}
				})
	 	      .setNegativeButton("No", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int button) {
						

					}
				});
	 	       return alert.create();
		}
		//HARVESTING
		if (id == 10){
			final AlertDialog.Builder alert = new AlertDialog.Builder(this);
	 	       
	 	       alert.setMessage("Would you like to harvest this matured Biofuel?")
	 	       .setTitle("Harvesting")
	 	       .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int button) {
						harvestOperations();

					}
				})
	 	      .setNegativeButton("No", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int button) {
						

					}
				});
	 	       return alert.create();
		}
		//NOT READY TO HARVEST
		if (id == 11){
			final AlertDialog.Builder alert = new AlertDialog.Builder(this);
			
			 alert.setMessage("This BioFuel has not fully matured yet.  Would you like to Harvest anyway?")
			 .setTitle("Harvesting")
	 	       .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int button) {
						harvestOperations();
						

					}
				})
			 .setNegativeButton("No", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int button) {
						

					}
				});
	 	       return alert.create();
		}
		return null;
	}
	
	public boolean canAffordMoney(int i){
		BioFuel b = null;
		if (i == 1){
			b = new BioFuel("Grass");			
		}
		if (i == 2){
			b = new BioFuel("Algae");			
		}
		if (i == 3){
			b = new BioFuel("Trees");			
		}
		if (farmMoney >= b.getPurchaseCost()){
			return true;
			
		} else {
			tempCost = b.getPurchaseCost() - farmMoney;
			
			showDialog(4);
			return false;
		}		
	}
	
	public boolean canAfford(int i){
		BioFuel b = null;
		if (i == 1){
			b = new BioFuel("Grass");			
		}
		if (i == 2){
			b = new BioFuel("Algae");			
		}
		if (i == 3){
			b = new BioFuel("Trees");			
		}
		if (farmMoney >= b.getPurchaseCost()){
			farmMoney -= b.getPurchaseCost();
			FarmMoney = (TextView) findViewById(R.id.farmmoney);
			FarmMoney.setText("$"+farmMoney);
			return true;
			
		} else {
			tempCost = b.getPurchaseCost() - farmMoney;
			
			showDialog(4);
			return false;
		}		
	}
	
	public void makeToast(String s){
	  	   String tempstr = s;
	  	   int duration = Toast.LENGTH_LONG ;
	  	   Toast toast = Toast.makeText(this, tempstr, duration);
	  	   toast.show();
	 }
	
	public void harvestOperations(){
		harvestValue = (int)( (double) theBioFuel.getYield()* (theBioFuel.maturityRatio()));
		farmMoney += harvestValue;
		FarmMoney = (TextView) findViewById(R.id.farmmoney);
		FarmMoney.setText("$"+farmMoney);
		theBioFuel = null;
		bioFuelChoice = 0;
		updateTexts();
		bioFuelButton.setImageDrawable(getResources().getDrawable(R.drawable.biofuelbuttonplant));
	}
	
	
	public void setPestAndBioFuel(){
		
		if (theBioFuel.getType().contains("Grass")) bioFuelButton.setImageDrawable(getResources().getDrawable(R.drawable.biofuelbuttonswitchgrass));
		if (theBioFuel.getType().contains("Algae")) bioFuelButton.setImageDrawable(getResources().getDrawable(R.drawable.biofuelbuttonalgae));
		if (theBioFuel.getType().contains("Trees")) bioFuelButton.setImageDrawable(getResources().getDrawable(R.drawable.biofuelbuttontrees));
	}
	
	@Override
	public void onBackPressed() {	 
		CountDownTimer countdown;		
		countdown = new CountDownTimer(1000 ,1000){

			@Override
			public void onFinish() {
				Intent j = new Intent();
				j.putExtra("plot", thePlot);
				
				j.putExtra("biofuel", theBioFuel);
				if (hasPest) j.putExtra("pest", thePest);
				j.putExtra("money", farmMoney);
				j.putExtra("harvested", hasHarvested);
				j.putExtra("harvestamount", harvestValue);
				setResult(1, j);
				finish();				
			}

			@Override
			public void onTick(long arg0) {
				// TODO Auto-generated method stub				
			}			
		};
		countdown.start();	   
	}
	
	
}
