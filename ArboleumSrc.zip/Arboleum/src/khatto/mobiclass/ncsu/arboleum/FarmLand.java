package khatto.mobiclass.ncsu.arboleum;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;

public class FarmLand {
	
	private Plot[] plots;
	
	private double pestPercentage;
	private double averageTemp;
	private int enviroHealth;
	private String locale;
	private Resources resources;
	private House house;
	
	private int money;
	
	private int highestFunds = 500;
	
	private int numberHarvested = 0;
	
	private int totalHarvestValue = 0;
	
	public int turnCount = 0;
	
	public enum Difficulty{
		Easy,
		Medium,
		Hard
	};
	
	public enum Season{
		Spring,
		Summer,
		Autumn,
		Winter
	}
	
	private Season season = Season.Spring;
	
	private Difficulty difficultySetting;
	
	public FarmLand(String l, Resources r){
		setLocale(l);
		resources = r;
		setup();
	}
	
	public Resources getResources(){
		return resources;
	}
	
	public void nextTurn(){
		/*
		for  (each Plot p : plots){
			p.nextTurn();
		}
		*/
		turnCount++;
		plots[0].nextTurn();
		plots[1].nextTurn();
		plots[2].nextTurn();
		plots[3].nextTurn();
		plots[4].nextTurn();
		plots[5].nextTurn();
		plots[6].nextTurn();
		plots[7].nextTurn();
		plots[8].nextTurn();
	}
	
	public void setup(){
		if (locale.equals("Piedmont")){
			pestPercentage = .15;
			difficultySetting = Difficulty.Easy;
			enviroHealth = 80;
			averageTemp = 78.5;
			
			money = 500;
			
			plots = new Plot[9];
			Plot p = new Plot(resources);
			p.setName("Plot One");
			p.piedmontSetup();
			p.setX(33);
			p.setY(0);	
			Plot q = new Plot(resources);
			q.setName("Plot Two");
			q.piedmontSetup();
			q.setX(p.getX()+50+p.getImageWidth());
			q.setY(0);
			Plot r = new Plot(resources);
			r.setName("Plot Three");
			r.piedmontSetup();
			r.setX(q.getX()+50+q.getImageWidth());
			r.setY(0);
			
			Plot a = new Plot(resources);
			a.setName("Plot Four");
			a.piedmontSetup();
			a.setX(33);
			a.setY(p.getY()+150);	
			Plot b = new Plot(resources);
			b.setName("Plot Five");
			b.piedmontSetup();
			b.setX(a.getX()+50+p.getImageWidth());
			b.setY(p.getY()+150);
			Plot c = new Plot(resources);
			c.setName("Plot Six");
			c.piedmontSetup();
			c.setX(b.getX()+50+q.getImageWidth());
			c.setY(p.getY()+150);
			
			Plot d = new Plot(resources);
			d.setName("Plot Seven");
			d.piedmontSetup();
			d.setX(33);
			d.setY(a.getY()+150);	
			Plot e = new Plot(resources);
			e.setName("Plot Eight");
			e.piedmontSetup();
			e.setX(d.getX()+50+p.getImageWidth());
			e.setY(a.getY()+150);
			Plot f = new Plot(resources);
			f.setName("Plot Nine");
			f.piedmontSetup();
			f.setX(e.getX()+50+q.getImageWidth());
			f.setY(a.getY()+150);
			
			plots[0] = p;			
			plots[1] = q;
			plots[2] = r;
			plots[3] = a;			
			plots[4] = b;
			plots[5] = c;
			plots[6] = d;			
			plots[7] = e;
			plots[8] = f;
			
		}		
	}
	
	public void drawPlots(Canvas canvas){
		canvas.drawBitmap(getPlot(1).getImage(), getPlot(1).getX(), getPlot(1).getY(), null);
        canvas.drawBitmap(getPlot(2).getImage(), getPlot(2).getX(), getPlot(2).getY(), null);
        canvas.drawBitmap(getPlot(3).getImage(), getPlot(3).getX(), getPlot(3).getY(), null);
        canvas.drawBitmap(getPlot(4).getImage(), getPlot(4).getX(), getPlot(4).getY(), null);
        canvas.drawBitmap(getPlot(5).getImage(), getPlot(5).getX(), getPlot(5).getY(), null);
        canvas.drawBitmap(getPlot(6).getImage(), getPlot(6).getX(), getPlot(6).getY(), null);
        canvas.drawBitmap(getPlot(7).getImage(), getPlot(7).getX(), getPlot(7).getY(), null);
        canvas.drawBitmap(getPlot(8).getImage(), getPlot(8).getX(), getPlot(8).getY(), null);
        canvas.drawBitmap(getPlot(9).getImage(), getPlot(9).getX(), getPlot(9).getY(), null);
	}

	public void setPlots(Plot[] plots) {
		this.plots = plots;
	}

	public Plot[] getPlots() {
		return plots;
	}

	public void setPestPercentage(int pestPercentage) {
		this.pestPercentage = pestPercentage;
	}

	public double getPestPercentage() {
		return pestPercentage;
	}

	public void setAverageTemp(int averageTemp) {
		this.averageTemp = averageTemp;
	}
	
	public void increaseHarvestCount(){
		numberHarvested++;
	}
	
	public int getHarvestCount(){
		return numberHarvested;
	}

	public double getAverageTemp() {
		return averageTemp;
	}

	public void setEnviroHealth(int enviroHealth) {
		this.enviroHealth = enviroHealth;
	}

	public int getEnviroHealth() {
		return enviroHealth;
	}

	public void setLocale(String locale) {
		this.locale = locale;
	}

	public String getLocale() {
		return locale;
	}
	
	public Plot getPlot(int i){
		return plots[(i-1)];
	}
	
	public void addMoney(int i){
		if (i + money < 0){
			money = 0;
		} else {
			money += i;
		}
	}
	
	public void setHappiness(){
		enviroHealth = 0;
		int numOfFuels = 0;
		for ( Plot p : plots){
			if (p.getBioFuel() != null) numOfFuels++;
			enviroHealth += (int) p.getNutrients();
		}
		if (numOfFuels > 0) enviroHealth /= numOfFuels;
		else enviroHealth = 80;
	}
	
	public void setSeason(String s){
		if (s.equals("Spring")) season = Season.Spring;
		if (s.equals("Summer")) season = Season.Summer;
		if (s.equals("Autumn")) season = Season.Autumn;
		if (s.equals("Winter")) season = Season.Winter;
	}
	
	public Season getSeason(){
		return season;
	}
	
	public int getMoney(){
		return money;
	}
	
	public void setMoney(int i){
		money = i;
	}
	
	public void checkForHigherFunds(){
		if (money > highestFunds) highestFunds = money;
	}
	
	public void addToTotal(int i){
		totalHarvestValue += i;
	}
	
	public int getTotalHarvestValue(){
		return totalHarvestValue;
	}
	

	public int getHighestFunds(){
		return highestFunds;
	}
	
	private class House{
		
		private Bitmap image;
		private Resources resources;
		private int x;
		private int y;
		
		public House(Resources r){
			resources = r;
			image = BitmapFactory.decodeResource(resources, R.drawable.housepiedmont);
		}

		public void setImage(Bitmap image) {
			this.image = image;
		}

		public Bitmap getImage() {
			return image;
		}

		public void setX(int x) {
			this.x = x;
		}

		public int getX() {
			return x;
		}
		
		
		

		public void setY(int y) {
			this.y = y;
		}

		public int getY() {
			return y;
		}
		
		
	}

}
