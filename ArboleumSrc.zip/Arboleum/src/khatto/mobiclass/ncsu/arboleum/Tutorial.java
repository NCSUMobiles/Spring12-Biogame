package khatto.mobiclass.ncsu.arboleum;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.LinearLayout;

public class Tutorial extends Activity{
	int currentImage = 1;
	LinearLayout background;
	Context con;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.tutorialview);
		background = (LinearLayout) findViewById(R.id.tutorialviewforid);
		background.setBackgroundResource(R.drawable.tutorial1);
		con = this;
		background.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				currentImage++;
				new PlaySound(con, "Correct");
				if (currentImage == 2){
					
					background.setBackgroundResource(R.drawable.tutorial2);
				}
				if (currentImage == 3){
					background.setBackgroundResource(R.drawable.tutorial3);
				}
				if (currentImage == 4){
					background.setBackgroundResource(R.drawable.tutorial4);
				}
				if (currentImage == 5){
					background.setBackgroundResource(R.drawable.tutorial5);
				}
				if (currentImage == 6){
					background.setBackgroundResource(R.drawable.tutorial6);
				}
				if (currentImage == 7){
					Intent j = new Intent(Tutorial.this, FarmLandActivity.class);
					startActivity(j);
					overridePendingTransition(R.anim.fadein, R.anim.fadeout);
					finish();
				}
				
			}
			
		});
	}

}
