package khatto.mobiclass.ncsu.arboleum;

import java.util.Random;

import android.os.Parcel;
import android.os.Parcelable;

public class Pest implements Parcelable{
	
	/**
	 * harmvalue - represents the value of damage that will be done each turn to a crop
	 * ran - the pest's personal Random Number Generator
	 * lifevalue- the projected time the pest will stay alive in number of turns
	 * alive - represents whether or not this pest is alive as indicated by the lifeValue
	 * 
	 */
	private int harmValue = 0;
	private Random ran;
	private int lifeValue;
	private boolean alive;
	private String description;
	private String pestName;
	
	private int resistance;
	private int idealTemp;
	private boolean active;
	
	
	public Pest(){
		ran = new Random();
		harmValue = ran.nextInt(5);
		lifeValue = ran.nextInt(10+1);
		alive = true;
		pestName = "Termite";
		description = "These pesky buggers tear through all sorts of wood.";
	}
	
	/** 
	 * @return the harmvalue
	 */
	public int getHarmValue(){
		return harmValue;
	}
	
	/** 
	 * @return the life
	 */
	public int getLife(){
		return lifeValue;
	}
	
	/** 
	 * @return whether or not the Pest is alive based on its remaining lifeValue
	 */
	public boolean isAlive(){
		return alive;
	}
	
	/** 
	 * NextTurn function that calculates the necessary changes when a new Turn is selected.
	 */
	public void nextTurn(){
		if (lifeValue > 0) lifeValue--;
		if (lifeValue == 0) alive = false;
	}

	@Override
	public int describeContents() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		
		dest.writeInt(harmValue);
		dest.writeInt(lifeValue);
		boolean[] aliveArray = new boolean[]{alive};		
		dest.writeBooleanArray(aliveArray);
		dest.writeString(description);
		dest.writeString(pestName);
		dest.writeInt(resistance);
		dest.writeInt(idealTemp);
		dest.writeBooleanArray(new boolean[]{active});
		
	}
	
	public Pest(Parcel par){
		this.harmValue = par.readInt();
		this.lifeValue = par.readInt();
		boolean[] aliveAnswers = new boolean[1];
		par.readBooleanArray(aliveAnswers);
		this.alive = aliveAnswers[0];
		this.description = par.readString();
		this.pestName = par.readString();
		this.resistance = par.readInt();
		this.idealTemp = par.readInt();
		boolean[] activeAnswers = new boolean[1];
		par.readBooleanArray(activeAnswers);
		this.active = activeAnswers[0];
	}
	
	public static final Parcelable.Creator<Pest> CREATOR = new Parcelable.Creator<Pest>() {
        public Pest createFromParcel(Parcel in) {
            return new Pest(in);
        }

        public Pest[] newArray(int size) {
            return new Pest[size];
        }
    };
	
	

}
