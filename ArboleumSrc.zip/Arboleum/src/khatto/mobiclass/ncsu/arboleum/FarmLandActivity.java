package khatto.mobiclass.ncsu.arboleum;


import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

public class FarmLandActivity extends Activity implements OnTouchListener{
	
	public FarmLand farmLand;
	public int turnNumber = 1;
	
	public PiedmontView piedmontView;	
	
	public enum Season{
		Spring,
		Summer,
		Autumn,
		Winter
	}
	public Season season;
	public GameUpdater updater;

	@Override
	public void onCreate(Bundle savedInstanceState) {	
		
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON, WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
		
		super.onCreate(savedInstanceState);
		
		DisplayMetrics metrics = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(metrics);
		int height = metrics.heightPixels;
		int width = metrics.widthPixels;		
		initialGameSetup();
		piedmontView = new PiedmontView(this, width, height, farmLand, this);		
		
		setContentView(piedmontView);				
	}
	
	public void initialGameSetup(){
		farmLand = new FarmLand("Piedmont", getResources());		
		season = Season.Spring;			
	}	
	
	public void viewPlot(int i){
		Intent j = new Intent(FarmLandActivity.this, PlotActivity.class);
		if (i == 1){			
			j.putExtra("plot", farmLand.getPlot(1));
			if (farmLand.getPlot(1).getBioFuel() != null) j.putExtra("biofuel", farmLand.getPlot(1).getBioFuel());
			j.putExtra("money", farmLand.getMoney());
		}
		if (i == 2){
			j.putExtra("plot", farmLand.getPlot(2));
			if (farmLand.getPlot(2).getBioFuel() != null) j.putExtra("biofuel", farmLand.getPlot(2).getBioFuel());
			j.putExtra("money", farmLand.getMoney());
		}
		if (i == 3){
			j.putExtra("plot", farmLand.getPlot(3));
			if (farmLand.getPlot(3).getBioFuel() != null) j.putExtra("biofuel", farmLand.getPlot(3).getBioFuel());
			j.putExtra("money", farmLand.getMoney());
		}
		if (i == 4){			
			j.putExtra("plot", farmLand.getPlot(4));
			if (farmLand.getPlot(4).getBioFuel() != null) j.putExtra("biofuel", farmLand.getPlot(4).getBioFuel());
			j.putExtra("money", farmLand.getMoney());
		}
		if (i == 5){
			j.putExtra("plot", farmLand.getPlot(5));
			if (farmLand.getPlot(5).getBioFuel() != null) j.putExtra("biofuel", farmLand.getPlot(5).getBioFuel());
			j.putExtra("money", farmLand.getMoney());
		}
		if (i == 6){
			j.putExtra("plot", farmLand.getPlot(6));
			if (farmLand.getPlot(6).getBioFuel() != null) j.putExtra("biofuel", farmLand.getPlot(6).getBioFuel());
			j.putExtra("money", farmLand.getMoney());
		}
		if (i == 7){			
			j.putExtra("plot", farmLand.getPlot(7));
			if (farmLand.getPlot(7).getBioFuel() != null) j.putExtra("biofuel", farmLand.getPlot(7).getBioFuel());
			j.putExtra("money", farmLand.getMoney());
		}
		if (i == 8){
			j.putExtra("plot", farmLand.getPlot(8));
			if (farmLand.getPlot(8).getBioFuel() != null) j.putExtra("biofuel", farmLand.getPlot(8).getBioFuel());
			j.putExtra("money", farmLand.getMoney());
		}
		if (i == 9){
			j.putExtra("plot", farmLand.getPlot(9));
			if (farmLand.getPlot(9).getBioFuel() != null) j.putExtra("biofuel", farmLand.getPlot(9).getBioFuel());
			j.putExtra("money", farmLand.getMoney());
		}
	
		//startActivity(j);
		startActivityForResult(j,1);
		
	}
	
	public void updatePlots(){
		
		if (farmLand.getPlot(1).getBioFuel() == null) farmLand.getPlot(1).setImage(BitmapFactory.decodeResource(getResources(), R.drawable.plotempty));
		if (farmLand.getPlot(1).getBioFuel() != null){
			if (farmLand.getPlot(1).getBioFuel().getCurrentTurn() == 0) farmLand.getPlot(1).setImage(BitmapFactory.decodeResource(getResources(), R.drawable.plotseeds));
		}
		if (farmLand.getPlot(2).getBioFuel() == null) farmLand.getPlot(2).setImage(BitmapFactory.decodeResource(getResources(), R.drawable.plotempty));
		if (farmLand.getPlot(2).getBioFuel() != null){
			if (farmLand.getPlot(2).getBioFuel().getCurrentTurn() == 0) farmLand.getPlot(2).setImage(BitmapFactory.decodeResource(getResources(), R.drawable.plotseeds));
		}
		if (farmLand.getPlot(3).getBioFuel() == null) farmLand.getPlot(3).setImage(BitmapFactory.decodeResource(getResources(), R.drawable.plotempty));
		if (farmLand.getPlot(3).getBioFuel() != null){
			if (farmLand.getPlot(3).getBioFuel().getCurrentTurn() == 0) farmLand.getPlot(3).setImage(BitmapFactory.decodeResource(getResources(), R.drawable.plotseeds));
		}
		if (farmLand.getPlot(4).getBioFuel() == null) farmLand.getPlot(4).setImage(BitmapFactory.decodeResource(getResources(), R.drawable.plotempty));
		if (farmLand.getPlot(4).getBioFuel() != null){
			if (farmLand.getPlot(4).getBioFuel().getCurrentTurn() == 0) farmLand.getPlot(4).setImage(BitmapFactory.decodeResource(getResources(), R.drawable.plotseeds));
		}
		if (farmLand.getPlot(5).getBioFuel() == null) farmLand.getPlot(5).setImage(BitmapFactory.decodeResource(getResources(), R.drawable.plotempty));
		if (farmLand.getPlot(5).getBioFuel() != null){
			if (farmLand.getPlot(5).getBioFuel().getCurrentTurn() == 0) farmLand.getPlot(5).setImage(BitmapFactory.decodeResource(getResources(), R.drawable.plotseeds));
		}
		if (farmLand.getPlot(6).getBioFuel() == null) farmLand.getPlot(6).setImage(BitmapFactory.decodeResource(getResources(), R.drawable.plotempty));
		if (farmLand.getPlot(6).getBioFuel() != null){
			if (farmLand.getPlot(6).getBioFuel().getCurrentTurn() == 0) farmLand.getPlot(6).setImage(BitmapFactory.decodeResource(getResources(), R.drawable.plotseeds));
		}
		if (farmLand.getPlot(7).getBioFuel() == null) farmLand.getPlot(7).setImage(BitmapFactory.decodeResource(getResources(), R.drawable.plotempty));
		if (farmLand.getPlot(7).getBioFuel() != null){
			if (farmLand.getPlot(7).getBioFuel().getCurrentTurn() == 0) farmLand.getPlot(7).setImage(BitmapFactory.decodeResource(getResources(), R.drawable.plotseeds));
		}
		if (farmLand.getPlot(8).getBioFuel() == null) farmLand.getPlot(8).setImage(BitmapFactory.decodeResource(getResources(), R.drawable.plotempty));
		if (farmLand.getPlot(8).getBioFuel() != null){
			if (farmLand.getPlot(8).getBioFuel().getCurrentTurn() == 0) farmLand.getPlot(8).setImage(BitmapFactory.decodeResource(getResources(), R.drawable.plotseeds));
		}
		if (farmLand.getPlot(9).getBioFuel() == null) farmLand.getPlot(9).setImage(BitmapFactory.decodeResource(getResources(), R.drawable.plotempty));
		if (farmLand.getPlot(9).getBioFuel() != null){
			if (farmLand.getPlot(9).getBioFuel().getCurrentTurn() == 0) farmLand.getPlot(9).setImage(BitmapFactory.decodeResource(getResources(), R.drawable.plotseeds));
		}
		if (farmLand.getMoney() <= 0) showDialog(1);
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data){
		//makeToast("UPDATE COMPLETE.");
		Intent i = data;
		Plot p = (Plot) i.getParcelableExtra("plot");
		BioFuel bio = new BioFuel("Grass");
		bio = (BioFuel) i.getParcelableExtra("biofuel");
		double moisture = p.getNutrients();
		farmLand.setMoney(i.getIntExtra("money", farmLand.getMoney()));
		if (i.getBooleanExtra("harvest",false) == true) farmLand.increaseHarvestCount();
		farmLand.addToTotal(i.getIntExtra("harvestamount", 0));
		farmLand.checkForHigherFunds();
		farmLand.setHappiness();
		String name = p.getName();
		if (name.contains("One")){
			farmLand.getPlot(1).setBioFuel(bio);
			farmLand.getPlot(1).setNutrients(moisture);			
		}
		if (name.contains("Two")){
			farmLand.getPlot(2).setBioFuel(bio);
			farmLand.getPlot(2).setNutrients(moisture);		
		}
		if (name.contains("Three")){
			farmLand.getPlot(3).setBioFuel(bio);
			farmLand.getPlot(3).setNutrients(moisture);		
		}
		if (name.contains("Four")){
			farmLand.getPlot(4).setBioFuel(bio);
			farmLand.getPlot(4).setNutrients(moisture);		
		}
		if (name.contains("Five")){
			farmLand.getPlot(5).setBioFuel(bio);
			farmLand.getPlot(5).setNutrients(moisture);		
		}
		if (name.contains("Six")){
			farmLand.getPlot(6).setBioFuel(bio);
			farmLand.getPlot(6).setNutrients(moisture);		
		}
		if (name.contains("Seven")){
			farmLand.getPlot(7).setBioFuel(bio);
			farmLand.getPlot(7).setNutrients(moisture);		
		}
		if (name.contains("Eight")){
			farmLand.getPlot(8).setBioFuel(bio);
			farmLand.getPlot(8).setNutrients(moisture);		
		}
		if (name.contains("Nine")){
			farmLand.getPlot(9).setBioFuel(bio);
			farmLand.getPlot(9).setNutrients(moisture);		
		}
		updatePlots();
		piedmontView.startThread();
	}

	@Override
	public boolean onTouch(View v, MotionEvent event) {
		
		return false;
	}
	
	public void toNextSeason(){
		
		if (season == Season.Winter){
			season = Season.Spring;
			farmLand.setSeason(season.toString());
		}
		else if (season == Season.Autumn){
			season = Season.Winter;
			farmLand.setSeason(season.toString());
		}
		else if (season == Season.Summer){
			season = Season.Autumn;
			farmLand.setSeason(season.toString());
		}
		else if (season == Season.Spring){
			season = Season.Summer;
			farmLand.setSeason(season.toString());
		}
		
	}
	
	
	@Override
	public boolean onTouchEvent(MotionEvent event) {
		// TODO Auto-generated method stub		
		return false;
	}
	
	 public void makeToast(String s){
  	   String tempstr = s;
  	   int duration = Toast.LENGTH_SHORT * 4;
  	   Toast toast = Toast.makeText(this, tempstr, duration);
  	   toast.show();
     }
	
	public void nextTurnActivities(){
		turnNumber++;
		toNextSeason();
		//farmLand.nextTurn();
		String s = season.toString();
		piedmontView.transition();
	}
	
	//REAL NEXT SEASON
	public void makeFarmTurn(){
		farmLand.nextTurn();
		if (farmLand.getMoney() <= 0) showDialog(1);
		if (turnNumber == 12){
			showDialog(5);
		}
	}
	
	@Override
	protected Dialog onCreateDialog( int id )
	{
		if (id == 1){
			final AlertDialog.Builder alert = new AlertDialog.Builder(this);
			alert.setMessage("You've ran out of money...  A good farmer NEVER runs out of money...")
	 	       .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int button) {
						finish();

					}
				});
	 	       return alert.create();
	 	      
		}
		
		if (id == 5){
			final AlertDialog.Builder alert = new AlertDialog.Builder(this);
			alert.setMessage("3 years has passed!  It's time to get evaluated by the BioFuels Committee!")
	 	       .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int button) {
						piedmontView.stopThread();
						Intent j = new Intent(FarmLandActivity.this, BioFuelCommittee.class);
						j.putExtra("harvest", farmLand.getHarvestCount());
						j.putExtra("health", farmLand.getEnviroHealth());
						j.putExtra("highest", farmLand.getHighestFunds());
						
						startActivity(j);
						overridePendingTransition(R.anim.fadein, R.anim.fadeout);
						finish();

					}
				});
	 	       return alert.create();
	 	      
		}
		
		//STATS
		if (id == 15){
			String theMessage = "";
			
			theMessage = "You have been farming BioFuels for "+turnNumber+" turns."
			+"\n\nYou have earned $"+(farmLand.getHarvestCount())+" since you started farming."
			+"\n\nYou have "+(12-turnNumber)+" more Seasons before you are evaluated by the BioFuels Committee."
			+"\n\nYour farm is at "+(int)farmLand.getEnviroHealth()+"% health.";
			
			return new AlertDialog.Builder( this )
	 	       .setTitle( "Stats" )
	 	       .setMessage(theMessage)
	 	       .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int button) {
						makeToast("Turn Number: "+turnNumber);
					}
				})
	 	       .create();		
	 	      
		}
		
		//HELP
		if (id == 16){
			final AlertDialog.Builder alert = new AlertDialog.Builder(this);
			alert.setMessage("FARM\n\n"
					+"\nMONEY - Money is indicated by the numerical value at the top of the Side Bar."
					+"\nHEALTH - The face icon represents the overall health of the Farm.  This is determined by calculating the total levels of Moisture and Toxicity each Plot has."
					+"\nSEASON - The season is indicated by either flowers for Spring, the sun for Summer, leaves for Fall, and a snowflake for Winter.  Tap the Season Icon in case you've forgotten what the season was."
					+"\nSILO - View your statistics and get help here."
					+"\nNEXT TURN - Proceed to the next Season.\n"
					+"PLOT VIEW\n\n"
					+"\nAGE - Represents the current seasons a BioFuel has been growing."
					+"\nMOISTURE - The amount of nutrients the plot has in moisture."
					+"\nTOXIC - Represents the level of toxins in the plot."
					+"\nHARVEST - Select to Harvest a BioFuel and get the crop."
					+"\nWATER - Water a BioFuel to increase its Moisture rating."
					
			
			
			
			
			
			).setTitle("Help")
	 	       .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int button) {

					}
				});
	 	       return alert.create();
	 	      
		}
		
		
		if (id == 35){
			final AlertDialog.Builder alert = new AlertDialog.Builder(this);
			alert.setMessage("Hello Farmer!  What would you like to view?")
			.setTitle("Silo")
	 	       .setPositiveButton("Stats", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int button) {
						showDialog(15);

					}
				})
			.setNeutralButton("Help", new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int button) {
					showDialog(16);

				}
			})
			.setNegativeButton("Back", new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int button) {
					

				}
			});
	 	       return alert.create();
	 	      
		}
		return null;
	}
	
	@Override
	  protected void onStart() {
	      super.onStart();
	      piedmontView.startThread();
	  }
	
	  @Override
	  protected void onResume() {
	      super.onResume();
	      piedmontView.startThread();
	  }
	  
	  @Override
	  protected void onPause() {
	      super.onPause();
	      piedmontView.stopThread();
	  }
	  
	  @Override
	  protected void onStop() {
	      super.onStop();
	      piedmontView.stopThread();
	  }
	  
	  public void transition(){
		  
	  }
	
	private class GameUpdater extends AsyncTask<Void, Integer, Void>{

   		
   		CountDownTimer countdown;
   		int timeLeft = 0;
   		
   		public void switchNums(){
   			int temp = 0;		
   		}   		
   		
   		@Override
   		  protected void onPreExecute() {
   		  }
   		
   		@Override
   		  protected void onPostExecute(Void result) {
   			//new MakeToast("It's Done With the AsyncTask", getApplicationContext());   			
   		   
   		  }

   		@Override
   		protected Void doInBackground(Void... params) {
   			Canvas c = null;
            try {
                   c = piedmontView.getHolder().lockCanvas();
                   synchronized (piedmontView.getHolder()) {
                	   piedmontView.onDraw(c);
                   }
            } finally {
                   if (c != null) {
                	   piedmontView.getHolder().unlockCanvasAndPost(c);
                   }
            }
   			return null;
   		}	
   	}
	
}
