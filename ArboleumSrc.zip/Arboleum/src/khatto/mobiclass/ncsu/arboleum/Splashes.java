package khatto.mobiclass.ncsu.arboleum;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.widget.LinearLayout;

public class Splashes extends Activity{

	LinearLayout layout;
	CountDownTimer countdown2;
	
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.splashlayout);
		layout = (LinearLayout) findViewById(R.id.splashlayoutid);		
		countdown2 = new CountDownTimer(1400, 1000){		
			
			@Override
			public void onFinish() {					
				Intent j = new Intent(Splashes.this, TitleScreen.class);
				startActivity(j);
				overridePendingTransition(R.anim.fadein, R.anim.fadeout);
				finish();
			} 

			@Override
			public void onTick (long millisUntilFinished) {
				
			}			
		};
								
		CountDownTimer countdown = new CountDownTimer(1400, 1000){		
			
			@Override
			public void onFinish() {					
				layout.setBackgroundDrawable(getResources().getDrawable(R.drawable.arboleum));		
				countdown2.start();
			} 

			@Override
			public void onTick (long millisUntilFinished) {
				
			}			
		};
			
		countdown2.start();
	}
	
}
