package khatto.mobiclass.ncsu.arboleum;

import java.util.Random;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.CountDownTimer;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.Toast;

public class PiedmontView extends SurfaceView implements OnTouchListener{
	
       public Bitmap background;
       private Bitmap sideBar;
       
       private Icon siloIcon;
       private Icon nextTurnIcon;
       private Icon seasonIcon;
       
       private SurfaceHolder holder;
       private int windowX;
       private int windowY;
       private FarmLand farm;
       private Context con;
       private FarmLandActivity main;
       
       private boolean started = false;
       private boolean surfacecreated = false;
       private boolean threadrunning = false;
       
       private int touchX = 0;
       private int touchY = 0;
       
       private boolean showRange = false;
       
       private boolean transitioning = false;
       private boolean transitioning2 = false;
       private boolean showingPicture = false;
       
       private Bitmap seasonPicture;
       
       private int fadeColor;
       
       public enum Season{
   			Spring,
   			Summer,
   			Autumn,
   			Winter
   		}
       
       
       PiedmontViewThread pvThread;       
 
       public PiedmontView(Context context, int x, int y, FarmLand f, FarmLandActivity farmmain) {
    	   
             super(context);
             con = context;
             holder = getHolder();
             farm = f;
             main = farmmain;
             pvThread = new PiedmontViewThread(this);          
             
             fadeColor = Color.argb(0, 0, 0, 0);
             
             holder.addCallback(new SurfaceHolder.Callback() {
 
                    @Override
                    public void surfaceDestroyed(SurfaceHolder holder) {
                    	/*
                    	 boolean retry = true;
                         pvThread.setRunning(false);
                         while (retry) {
                                try {
                                      pvThread.join();
                                      retry = false;
                                } catch (InterruptedException e) {
                                	pvThread.setRunning(false);
                                }
                                
                         }
                         */
                        
                    }
 
                    @Override
                    public void surfaceCreated(SurfaceHolder holder) {
                    	
                    	surfacecreated = true;
                    	startThread();
                    }
 
                    @Override
                    public void surfaceChanged(SurfaceHolder holder, int format,
                                  int width, int height) {
                    	
                    }
             });
             windowX = x;
             windowY = y;
             background = BitmapFactory.decodeResource(getResources(), R.drawable.backgroundpiedmont);
             background = background.createScaledBitmap(background, windowX, windowY, false);
             sideBar = BitmapFactory.decodeResource(getResources(), R.drawable.sidebar);
             sideBar = sideBar.createScaledBitmap(sideBar, sideBar.getWidth()/3, windowY, false);
             
             siloIcon = new Icon("Silo", farm.getResources(), windowX-sideBar.getWidth(), windowY);
             nextTurnIcon = new Icon("NextTurn", farm.getResources(), windowX-sideBar.getWidth(), windowY);
             seasonIcon = new Icon("SeasonIcon", farm.getResources(), windowX-sideBar.getWidth(), windowY);
       }
       
 
       @Override
       protected void onDraw(Canvas canvas) {  
    	   
             canvas.drawBitmap(background, 0, 0, null);  
             farm.drawPlots(canvas);
             Paint paint = new Paint();
             
             paint.setColor(Color.WHITE);
             
             //canvas.drawText((String) ("TOUCH Y: "+touchY), farm.getPlot(1).getX()+15, farm.getPlot(1).getY()+45, paint);
             
             //DRAW SIDEBAR
             canvas.drawBitmap(sideBar, windowX-sideBar.getWidth(), 0, null); 
             
             nextTurnIcon.Draw(canvas);
             siloIcon.Draw(canvas);
             
             
             Paint textPaint = new Paint();
             textPaint.setColor(Color.BLACK);
             textPaint.setTextSize(25);
             
             String moneyString = "$"+farm.getMoney();
             
             String farmHealthString = "";
             canvas.drawText(moneyString, windowX-sideBar.getWidth()+25, 30, textPaint);
             Bitmap health;
             
             if (farm.getEnviroHealth() >= 80){
            	 health = BitmapFactory.decodeResource(getResources(), R.drawable.healthhappy); 
            	 canvas.drawBitmap(health, windowX-sideBar.getWidth()+15, 47, null);
             }
             else if (farm.getEnviroHealth() >= 60){
            	 health = BitmapFactory.decodeResource(getResources(), R.drawable.healthmedium); 
            	 canvas.drawBitmap(health, windowX-sideBar.getWidth()+15, 47, null);
             }
             else {
            	 health = BitmapFactory.decodeResource(getResources(), R.drawable.healthsad); 
            	 canvas.drawBitmap(health, windowX-sideBar.getWidth()+15, 47, null);
             }
             
             
             if (farm.getSeason().toString() == "Spring"){
            	 seasonIcon.setSeason("Spring");
            	 
             }
             if (farm.getSeason().toString() == "Summer"){
            	 seasonIcon.setSeason("Summer");
             }
             if (farm.getSeason().toString() == "Autumn"){
            	 seasonIcon.setSeason("Autumn");
             }
             if (farm.getSeason().toString() == "Winter"){
            	 seasonIcon.setSeason("Winter");
             }
             seasonIcon.Draw(canvas);
             
             canvas.drawText(farmHealthString, windowX-paint.measureText(farmHealthString)-paint.measureText(farmHealthString), windowY-35, paint);
             if (transitioning) canvas.drawColor(fadeColor);
             if (showingPicture){
            	 if (farm.getSeason().toString() == Season.Spring.toString()){
            		 seasonPicture = BitmapFactory.decodeResource(getResources(), R.drawable.seasonpicspring);
            		 seasonPicture = seasonPicture.createScaledBitmap(seasonPicture, windowX, windowY, false);
            		 background = BitmapFactory.decodeResource(getResources(), R.drawable.backgroundpiedmont);
                     background = background.createScaledBitmap(background, windowX, windowY, false);
            	 }
            	 else if (farm.getSeason().toString() == Season.Summer.toString()){
            		 seasonPicture = BitmapFactory.decodeResource(getResources(), R.drawable.seasonpicsummer);
            		 seasonPicture = seasonPicture.createScaledBitmap(seasonPicture, windowX, windowY, false);
            		 background = BitmapFactory.decodeResource(getResources(), R.drawable.backgroundpiedmontsummer);
                     background = background.createScaledBitmap(background, windowX, windowY, false);
            	 }
            	 else if (farm.getSeason().toString() == Season.Autumn.toString()){
            		 seasonPicture = BitmapFactory.decodeResource(getResources(), R.drawable.seasonpicautumn);
            		 seasonPicture = seasonPicture.createScaledBitmap(seasonPicture, windowX, windowY, false);
            		 background = BitmapFactory.decodeResource(getResources(), R.drawable.backgroundpiedmontautumn);
                     background = background.createScaledBitmap(background, windowX, windowY, false);
            	 }
            	 else if (farm.getSeason().toString() == Season.Winter.toString()){
            		 seasonPicture = BitmapFactory.decodeResource(getResources(), R.drawable.seasonpicwinter);
            		 seasonPicture = seasonPicture.createScaledBitmap(seasonPicture, windowX, windowY, false);
            		 background = BitmapFactory.decodeResource(getResources(), R.drawable.backgroundpiedmontwinter);
                     background = background.createScaledBitmap(background, windowX, windowY, false);
            	 }
            	 
                 canvas.drawBitmap(seasonPicture, 0, 0, null);
             }
             if (transitioning2) canvas.drawColor(fadeColor);
             
            
       }
       
       public void transition(){
    	   transitioning = true;
    	   
    	   final CountDownTimer fadeToFarm = new CountDownTimer(1000,10){

    		   int faderate = 250;
    		   int evenodd = 0;
   			@Override
   			public void onFinish() {
   				transitioning = false;
   				transitioning2 = false;
   			}

   			@Override
   			public void onTick(long arg0) {
   				if ((faderate -2) >= 0) faderate -= 2;
   				if ((faderate -1) >= 0 && evenodd % 2 == 1) faderate -= 1;
				fadeColor = Color.argb(faderate, 0, 0, 0);
   				
   			}
       		   
       	   };
    	   
    	   final CountDownTimer fade2 = new CountDownTimer(1000,10){
    		   int faderate = 0;
    		   int evenodd = 0;
    		   
			@Override
			public void onFinish() {
				fadeColor = Color.argb(255, 0, 0, 0);
				fadeToFarm.start();	
				showingPicture = false;
			}

			@Override
			public void onTick(long arg0) {
				if ((faderate +2) <= 255) faderate += 2;
				if ((faderate +1) <= 255 && evenodd % 2 == 1) faderate += 1;
				fadeColor = Color.argb(faderate, 0, 0, 0);
			}    		   
    	   };
    	   
    	   final CountDownTimer waitForFive = new CountDownTimer(3000,100){

    		   
   			@Override
   			public void onFinish() {
   				fade2.start();
   				transitioning2 = true;
   			}

   			@Override
   			public void onTick(long arg0) {
   				
   			}
       		   
       	   };
    	   
    	   
    	   final CountDownTimer fadeToPicture = new CountDownTimer(1000,10){

    		   int faderate = 250;
    		   int evenodd = 0;
   			@Override
   			public void onFinish() {
   				waitForFive.start();
   				
   			}

   			@Override
   			public void onTick(long arg0) {
   				if ((faderate -2) >= 0) faderate -= 2;
   				if ((faderate -1) >= 0 && evenodd % 2 == 1) faderate -= 1;
				fadeColor = Color.argb(faderate, 0, 0, 0);
   				
   			}
       		   
       	   };
       	   
       	   
       	   
    	   CountDownTimer fade = new CountDownTimer(1000,10){
    		   int faderate = 0;
    		   int evenodd = 0;
    		   
			@Override
			public void onFinish() {
				fadeColor = Color.argb(255, 0, 0, 0);
				showingPicture = true;
				makeToast(randomQuote());
				fadeToPicture.start();	
				main.makeFarmTurn();
			}

			@Override
			public void onTick(long arg0) {
				if ((faderate +2) <= 255) faderate += 2;
				if ((faderate +1) <= 255 && evenodd % 2 == 1) faderate += 1;
				fadeColor = Color.argb(faderate, 0, 0, 0);
			}    		   
    	   };
    	  
    	   fade.start();
       }

       public void updateFarmLand(FarmLand f){
    	   farm = f;
       }      
       
       @Override
   		public boolean onTouch(View v, MotionEvent event) {   		   		
    	  
   			return false;
   		}
       
       @Override
  		public boolean onTouchEvent(MotionEvent event) {   	
    	   
    	   if (transitioning == false){
    		   
    		   touchX = (int) event.getX();
    	   	   touchY = (int) event.getY();   	
    	   	   
    	   	   if (nextTurnIcon.isTouched(touchX, touchY)){
    	   		   main.nextTurnActivities();
    	   	   }
    	   	   if (seasonIcon.isTouched(touchX, touchY)){
    	   		   makeToast("The Season is currently "+farm.getSeason().toString()+".");
    	   	   }
    	   	if (siloIcon.isTouched(touchX, touchY)){
 	   		   siloCelebrations();
 	   	   }
    	   	  	   	
    	   	   if (farm.getPlot(1).isTouched(touchX, touchY)){
    	   		  stopThread();
    	   		   main.viewPlot(1);
    	   	   }
    	   	   if (farm.getPlot(2).isTouched(touchX, touchY)){
    	 		  stopThread();
    	 		   main.viewPlot(2);
    	 	   }
    	   	   if (farm.getPlot(3).isTouched(touchX, touchY)){
    	 		  stopThread();
    	 		   main.viewPlot(3);
    	 	   }
    	   	if (farm.getPlot(4).isTouched(touchX, touchY)){
    			  stopThread();
    			   main.viewPlot(4);
    		   }
    	   	if (farm.getPlot(5).isTouched(touchX, touchY)){
    			  stopThread();
    			   main.viewPlot(5);
    		   }
    	   	if (farm.getPlot(6).isTouched(touchX, touchY)){
    			  stopThread();
    			   main.viewPlot(6);
    		   }
    	   	if (farm.getPlot(7).isTouched(touchX, touchY)){
    			  stopThread();
    			   main.viewPlot(7);
    		   }
    	   	if (farm.getPlot(8).isTouched(touchX, touchY)){
    			  stopThread();
    			   main.viewPlot(8);
    		   }
    	   	if (farm.getPlot(9).isTouched(touchX, touchY)){
    			  stopThread();
    			   main.viewPlot(9);
    		   }
    	   }
  		
   	   
   	    		
  			return false;
  		}
       
       public void startThread(){
    	   if(!surfacecreated) return;
    	    if(threadrunning) return;
    	    pvThread = new PiedmontViewThread(this);
    	    pvThread.setRunning(true);
    	    pvThread.start();
    	    threadrunning = true;
       }
       
       public void stopThread(){
    	   boolean retry = true;
    	    while (retry) {
    	        try {
    	            pvThread.setRunning(false);
    	            pvThread.join();
    	            threadrunning = false;
    	            retry = false;

    	        } catch (InterruptedException e) {}
    	    }
       }
       
       public void siloCelebrations(){
    	   main.showDialog(35);
       }
	
       public void makeToast(String s){
    	   String tempstr = s;
    	   int duration = Toast.LENGTH_LONG * 3;
    	   Toast toast = Toast.makeText(con, tempstr, duration);
    	   toast.show();
       }
       
       public String randomQuote(){
    	   String quote = "";
    	   Random ran = new Random();
    	   int num;
    	   num = ran.nextInt(12);
    	   if (num == 0) quote = "Ethanol and biodiesel allow people to burn a cleaner form of energy. ~Mark Kennedy";
    	   if (num == 1) quote = "I love the idea that biodiesel has the potential to support farmers, especially the family farms. ~Daryl Hannah";
    	   if (num == 2) quote = "The biodiesel we use is 100 percent, it has no petroleum in it. It was already used in fryers throughout our local area. It's already had one life and now it's going to be used again, which is nice. ~Daryl Hannah";
    	   if (num == 3) quote = "We should increase our development of alternative fuels, taking advantage of renewable resources, like using corn and sugar to produce ethanol or soybeans to produce biodiesel. ~Bobby Jindal";
    	   if (num == 4) quote = "Biodiesel is not flammable and has a flash point which is higher than that of fossil diesel. This means that it is much safer to store than fossil diesel.";
    	   if (num == 5) quote = "The harmful emissions that you would have when running fossil diesel are dramatically reduced when running even a small percentage of biodiesel.";
    	   if (num == 6) quote = "Biodiesel is more lubricating than petroleum diesel fuel so it has the potential to increase engine life. ";
    	   if (num == 7) quote = "Biodiesel can be blended with petroleum diesel in any ratio. The ratio is indicated with a B rating. B20 is 20 percent biodiesel, B80 is 80 percent biodiesel.";
    	   if (num == 8) quote = "In 2008 700 million gallons of biodiesel was produced in the US.";
    	   if (num == 9) quote = "In some countries biodiesel fuel prices are higher than that of normal diesel and in some countries you will have biodiesel blended into your fuel by law.";
    	   if (num == 10) quote = "The energy content of biodiesel is about 90 percent that of petroleum diesel.";
    	   if (num == 11) quote = "Biodiesel is a renewable fuel that can be manufactured from algae, vegetable oils, animal fats or recycled restaurant greases; it can be produced locally in most countries.";
    	   return quote;
       }
       
              
       private class PiedmontViewThread extends Thread{
    	   private PiedmontView view;
           private boolean running = false;
          
           public PiedmontViewThread(PiedmontView view) {
                 this.view = view;
           }
     
           public void setRunning(boolean run) {
                 running = run;
           }
     
           @Override
           public void run() {
                 while (running) {
                	 Canvas c = null;
                     try {
                            c = view.getHolder().lockCanvas();
                            synchronized (view.getHolder()) {
                            	if (farm.getSeason().toString() == Season.Spring.toString()){
                           		 background = BitmapFactory.decodeResource(getResources(), R.drawable.backgroundpiedmont);
                                    background = background.createScaledBitmap(background, windowX, windowY, false);
                           	 }
                           	 else if (farm.getSeason().toString() == Season.Summer.toString()){
                           		 background = BitmapFactory.decodeResource(getResources(), R.drawable.backgroundpiedmontsummer);
                                    background = background.createScaledBitmap(background, windowX, windowY, false);
                           	 }
                           	 else if (farm.getSeason().toString() == Season.Autumn.toString()){
                           		 background = BitmapFactory.decodeResource(getResources(), R.drawable.backgroundpiedmontautumn);
                                    background = background.createScaledBitmap(background, windowX, windowY, false);
                           	 }
                           	 else if (farm.getSeason().toString() == Season.Winter.toString()){
                           		 background = BitmapFactory.decodeResource(getResources(), R.drawable.backgroundpiedmontwinter);
                                    background = background.createScaledBitmap(background, windowX, windowY, false);
                           	 }
                                   view.onDraw(c);
                            }
                     } finally {
                            if (c != null) {
                                   view.getHolder().unlockCanvasAndPost(c);
                            }
                     }
                 }
           }
       }
}