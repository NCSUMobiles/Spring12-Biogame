package khatto.mobiclass.ncsu.arboleum;

import android.content.Context;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;

public class PlaySound {

	MediaPlayer mp;
	Context con;
	
	public PlaySound(Context c, String s){
		con = c;
		if (s.equals("Correct")){
			mp = MediaPlayer.create(con, R.raw.rightjingle);
			mp.start();			
            mp.setOnCompletionListener(new OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    mp.release();
                }
            });
		}
		if (s.equals("Water")){
			mp = MediaPlayer.create(con, R.raw.water);
			mp.start();			
            mp.setOnCompletionListener(new OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    mp.release();
                }
            });
		}
		if (s.equals("Plot")){
			mp = MediaPlayer.create(con, R.raw.plant);
			mp.start();			
            mp.setOnCompletionListener(new OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    mp.release();
                }
            });
		}
		if (s.equals("Harvest")){
			mp = MediaPlayer.create(con, R.raw.harvest);
			mp.start();			
            mp.setOnCompletionListener(new OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    mp.release();
                }
            });
		}
		
		if (s.equals("Wrong")){
			mp = MediaPlayer.create(con, R.raw.wrongjingle);
			mp.start();			
            mp.setOnCompletionListener(new OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    mp.release();
                }
            });
		}
		/*
		if (s.equals("Whistle")){
			mp = MediaPlayer.create(con, R.raw.whistle);
			mp.start();			
            mp.setOnCompletionListener(new OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    mp.release();
                }
            });
		}
		*/
		if (s.equals("Confirm")){
			mp = MediaPlayer.create(con, R.raw.confirmjingle);
			mp.start();			
            mp.setOnCompletionListener(new OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    mp.release();
                }
            });
		}
		
	}
}
